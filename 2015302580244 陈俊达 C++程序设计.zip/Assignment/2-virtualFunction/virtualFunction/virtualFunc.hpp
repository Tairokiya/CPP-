//
//  virtualFunc.hpp
//  virtualFunction
//
//  Created by Mike on 16/3/8.
//  Copyright © 2016年 陈 俊达. All rights reserved.
//

#ifndef virtualFunc_hpp
#define virtualFunc_hpp

#include <stdio.h>

#endif /* virtualFunc_hpp */
