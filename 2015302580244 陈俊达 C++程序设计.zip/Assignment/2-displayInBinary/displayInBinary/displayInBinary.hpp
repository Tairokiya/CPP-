//
//  displayInBinary.hpp
//  displayInBinary
//
//  Created by Mike on 16/3/8.
//  Copyright © 2016年 陈 俊达. All rights reserved.
//

#ifndef displayInBinary_hpp
#define displayInBinary_hpp

#include <stdio.h>

void displayBinary(void * data, int size);

#endif /* displayInBinary_hpp */
